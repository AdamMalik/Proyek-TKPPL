<?php

	$koneksi = mysqli_connect("localhost","root","","dbjualan") or die("tidak bisa tersambun ke database");

?>